`timescale 1ns / 1ps
`include "aquila_config.vh"

module bpu #( parameter ENTRY_NUM = 64, parameter XLEN = 32 ) // 改ENTRY_NUM就是改bht大小
(
    // System signals
    input               clk_i,
    input               rst_i,
    input               stall_i,

    // from Program_Counter
    input  [XLEN-1 : 0] pc_i,

    // from Decode
    input               is_jal_i,
    input               is_cond_branch_i,
    input  [XLEN-1 : 0] dec_pc_i,

    // from Execute
    input               exe_is_branch_i,
    input               branch_taken_i,
    input               branch_misprediction_i,
    input  [XLEN-1 : 0] branch_target_addr_i,

    // to Program_Counter
    output              branch_hit_o,
    output              branch_decision_o,
    output [XLEN-1 : 0] branch_target_addr_o,

    //new
    (* mark_debug = "true", keep = "true" *) output [63:0]       bpu_br_hit_o,     // 條件分支 BTB 命中次數
    (* mark_debug = "true", keep = "true" *) output [63:0]       bpu_br_miss_o,    // 條件分支 BTB 未命中次數
    (* mark_debug = "true", keep = "true" *) output [63:0]       bpu_br_misp_o,    // 條件分支 預測錯誤次數（mispredict）

    (* mark_debug = "true", keep = "true" *) output [63:0]       bpu_jal_hit_o,    // JAL BTB 命中次數
    (* mark_debug = "true", keep = "true" *) output [63:0]       bpu_jal_miss_o,   // JAL BTB 未命中次數
    (* mark_debug = "true", keep = "true" *) output [63:0]       bpu_jal_misp_o    // JAL 預測錯誤次數（mispredict）
);

localparam NBITS = $clog2(ENTRY_NUM);

wire [NBITS-1 : 0]      read_addr;
wire [NBITS-1 : 0]      write_addr;
wire [XLEN-1 : 0]       branch_inst_tag;
wire                    we;
reg                     BHT_hit_ff, BHT_hit;

// two-bit saturating counter
reg  [1 : 0]            branch_likelihood[ENTRY_NUM-1 : 0];

// "we" is enabled to add a new entry to the BHT table when
// the decoded branch instruction is not in the BHT.
assign we = ~stall_i & (is_cond_branch_i | is_jal_i) & !BHT_hit;

assign read_addr  = pc_i[NBITS+1 : 2];
assign write_addr = dec_pc_i[NBITS+1 : 2];

// new
reg is_jal_d1, is_jal_d2;
reg is_br_d1,  is_br_d2;

always @(posedge clk_i) begin
    if (rst_i) begin
        is_jal_d1 <= 1'b0; is_jal_d2 <= 1'b0;
        is_br_d1  <= 1'b0; is_br_d2  <= 1'b0;
    end else if (!stall_i) begin
        is_jal_d1 <= is_jal_i;
        is_jal_d2 <= is_jal_d1;        //  EX 對齊
        is_br_d1  <= is_cond_branch_i;
        is_br_d2  <= is_br_d1;         //  EX 對齊
    end
end

// new
reg [63:0] stat_br_hit,  stat_br_miss,  stat_br_misp;
reg [63:0] stat_jal_hit, stat_jal_miss, stat_jal_misp;

assign bpu_br_hit_o   = stat_br_hit;
assign bpu_br_miss_o  = stat_br_miss;
assign bpu_br_misp_o  = stat_br_misp;

assign bpu_jal_hit_o  = stat_jal_hit;
assign bpu_jal_miss_o = stat_jal_miss;
assign bpu_jal_misp_o = stat_jal_misp;

integer idx;

always @(posedge clk_i)
begin
    if (rst_i)
    begin
        // 初始化
        for (idx = 0; idx < ENTRY_NUM; idx = idx + 1)
            branch_likelihood[idx] <= 2'b0;

        // new
        stat_br_hit  <= 64'd0;
        stat_br_miss <= 64'd0;
        stat_br_misp <= 64'd0;
        stat_jal_hit  <= 64'd0;
        stat_jal_miss <= 64'd0;
        stat_jal_misp <= 64'd0;
    end
    else if (stall_i)
    begin
        for (idx = 0; idx < ENTRY_NUM; idx = idx + 1)
            branch_likelihood[idx] <= branch_likelihood[idx];
    end
    else
    begin
        if (we) // 第一次遇到該分支（或 JAL），建立 entry 並初始化 2-bit
        begin
            branch_likelihood[write_addr] <= {branch_taken_i, branch_taken_i};
            // new
            if (is_jal_d1) begin
                stat_jal_miss <= stat_jal_miss + 1'b1;
            end else if (is_br_d1) begin
                stat_br_miss <= stat_br_miss + 1'b1;
            end

        end
        else if (exe_is_branch_i)
        begin
            case (branch_likelihood[write_addr])
                2'b00:  // 強 not-taken
                    if (branch_taken_i)
                        branch_likelihood[write_addr] <= 2'b01;
                    else
                        branch_likelihood[write_addr] <= 2'b00;
                2'b01:  // 弱 not-taken
                    if (branch_taken_i)
                        branch_likelihood[write_addr] <= 2'b11;
                    else
                        branch_likelihood[write_addr] <= 2'b00;
                2'b10:  // 弱 taken
                    if (branch_taken_i)
                        branch_likelihood[write_addr] <= 2'b11;
                    else
                        branch_likelihood[write_addr] <= 2'b00;
                2'b11:  // 強 taken
                    if (branch_taken_i)
                        branch_likelihood[write_addr] <= 2'b11;
                    else
                        branch_likelihood[write_addr] <= 2'b10;
            endcase

            // new
            if (is_jal_d1) begin
                if (BHT_hit) stat_jal_hit  <= stat_jal_hit  + 1'b1;
                
                if (branch_misprediction_i)
                    stat_jal_misp <= stat_jal_misp + 1'b1;
            end else if (is_br_d1) begin
                if (BHT_hit) stat_br_hit  <= stat_br_hit  + 1'b1;

                if (branch_misprediction_i)
                    stat_br_misp <= stat_br_misp + 1'b1;
            end
        end
    end
end

// ===========================================================================
//  Branch History Table (BHT). Here, we use a direct-mapping cache table to
//  store branch history. Each entry of the table contains two fields:
//  the branch_target_addr and the PC of the branch instruction (as the tag).
distri_ram #(.ENTRY_NUM(ENTRY_NUM), .XLEN(XLEN*2))
BPU_BHT(
    .clk_i(clk_i),
    .we_i(we),                  // Write-enabled when the instruction at the Decode
                                //   is a branch and has never been executed before.
    .write_addr_i(write_addr),  // Direct-mapping index for the branch at Decode.
    .read_addr_i(read_addr),    // Direct-mapping Index for the next PC to be fetched.

    .data_i({branch_target_addr_i, dec_pc_i}), // Input is not used when 'we' is 0.
    .data_o({branch_target_addr_o, branch_inst_tag})
);

// Delay the BHT hit flag at the Fetch stage for two clock cycles (plus stalls)
// such that it can be reused at the Execute stage for BHT update operation.
always @ (posedge clk_i)
begin
    if (rst_i) begin
        BHT_hit_ff <= 1'b0;
        BHT_hit    <= 1'b0;
    end
    else if (!stall_i) begin
        BHT_hit_ff <= branch_hit_o;
        BHT_hit    <= BHT_hit_ff;
    end
end

// ===========================================================================
//  Outputs signals
// 
assign branch_hit_o      = (branch_inst_tag == pc_i);
assign branch_decision_o = branch_likelihood[read_addr][1];

endmodule
